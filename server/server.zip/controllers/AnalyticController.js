const fs = require("fs");
const { getUID } = require("../user_data/userInfo.js");
const getMulterUpload = require("../middlewares/MulterConfig.js");

const showHeader = async (req, res, next) => {};

module.exports = {
  showHeader,
};
