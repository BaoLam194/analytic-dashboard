import pandas as pd
import matplotlib.pyplot as plt

excel_file ="D:/bao_lam/repos/analytic-dashboard/server/testing/Timothy_TD19_ICQ4.csv"

df = pd.read_csv(excel_file)

plt.show()