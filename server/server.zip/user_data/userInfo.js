// userinfo.js
let curUID = "";

function setUID(uid) {
  curUID = uid;
}

function getUID() {
  return curUID;
}

module.exports = {
  setUID,
  getUID,
};
