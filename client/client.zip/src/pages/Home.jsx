import styles from "./Home.module.css";
import { Link } from "react-router-dom";
import Card from "../components/Card";

// This page is for the introduction / not-logged-in view
export default function Home() {
  return (
    <>
      <header>
        <nav>
          <Link to="/" className={styles.icon}>
            <img src="/vite.svg" alt="logo" />
            <h2>DataLytics</h2>
          </Link>
        </nav>
        <div className={styles.auth}>
          <Link to="/auth/login">
            <button className={`${styles.btn} ${styles["btn-white"]}`}>
              Log in
            </button>
          </Link>
          <Link to="/auth/signup">
            <button className={`${styles.btn} ${styles["btn-black"]}`}>
              Sign up
            </button>
          </Link>
        </div>
      </header>

      <main>
        <section className={styles.headline}>
          <h1>
            Transform Your Data Into{" "}
            <span className={styles.highlight}>Insights</span>
          </h1>
          <p className={styles.subtext}>
            Upload, clean, transform, and visualize your data with our powerful
            analytics platform. Support for CSV and Excel files with advanced
            data manipulation tools.
          </p>
        </section>

        <section className={styles.mainbtn}>
          <Link to="/">
            <button className={`${styles.btn} ${styles["btn-black"]}`}>
              Get started now!
            </button>
          </Link>
          <Link to="/">
            <button className={`${styles.btn} ${styles["btn-white"]}`}>
              View demo
            </button>
          </Link>
        </section>

        <section className={styles.feature}>
          <h1 className={styles.featuretitle}>Powerful features</h1>
          <div className={styles.cardcontainer}>
            <Card
              source="/vite.svg"
              title="Data Upload"
              description="Upload CSV and Excel files with drag-and-drop support"
            />
            <Card
              source="/vite.svg"
              title="Data Transformation"
              description="Clean, format, and reshape your data to make it analysis-ready with just a few clicks"
            />
            <Card
              source="/vite.svg"
              title="Visualization"
              description="Create beautiful charts and graphs from your data"
            />
            <Card
              source="/vite.svg"
              title="Dataset Management"
              description="Save and manage multiple versions of your datasets"
            />
            <Card
              source="/vite.svg"
              title="User Authentication"
              description="Secure login and user management system"
            />
            <Card
              source="/vite.svg"
              title="Advanced Analytics"
              description="Statistical analysis and data insights"
            />
          </div>
        </section>
      </main>

      <footer>Copyright@Orbital2025</footer>
    </>
  );
}
